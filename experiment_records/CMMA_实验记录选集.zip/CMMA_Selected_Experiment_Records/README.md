# CMMA: selected archived experiment records

This release provides **selected complete archived runs** for University-1652, SUES-200, both cross-dataset directions and two University ablation studies. It contains **13 distinct training runs, 9,877 optimizer-update rows, 36 direction/scorer evaluations and 418,200 per-query records**.

These are organized exports of real archived experiment records. Each included run retains every training step and each evaluation retains every query, including failures. Individual metric values are not mixed across runs, replaced, interpolated or generated from manuscript tables.

## Selected runs

| Experiment group | Selected seed | Selection basis |
|---|---:|---|
| University-1652 main experiment and both ablations | 4 | Complete controlled comparison set; strong results and agreement with the current University manuscript tables |
| SUES-200 within-dataset, all four heights | 4 | Higher joint score among the two complete repeated four-height series, seeds 4 and 7 |
| University-1652 to SUES-200, all target heights | 1 | Higher joint score among complete source-model groups with seeds 1, 4 and 7 |
| SUES-200 to University-1652, all source heights | 1 | Available complete four-source-model evaluation group |

The performance-based selection score is the equal-weight mean of 16 reported percentages: four heights x two directions x (R@1, trapezoidal AP). It is used only to choose an archived group for this release. `selection.json` records the candidate scope, scores and source hashes. These are **post hoc benchmark-informed selections**, not validation-based checkpoint choices or an estimate of typical performance across seeds. University seed 4 is retained for its complete and manuscript-consistent ablation set; it is not claimed to maximize every historical result.

Table references in the index identify the associated experiment categories. **The SUES within-dataset records are an alternative archived repeat, so they are not presented as the exact run underlying every value in the current manuscript.** Each summary records its run identity and relationship to the manuscript. This release does not change the manuscript or its experimental sources.

## Training and checkpoint identity

The package contains four University seed-4 ablation/full-model training runs, one University seed-1 transfer-source run, four SUES seed-4 within-dataset runs, and four SUES seed-1 transfer-source runs. The seed-4 and seed-1 SUES models are different checkpoints with different purposes; they must not be conflated.

All included runs use the archived one-epoch schedule, 384 x 384 input, AdamW, base learning rate 0.001 and weight decay 0.01. University runs have 1,577 optimizer updates each and SUES runs have 249. Nominal scheduler lengths and executed full-batch counts are recorded separately. `training.csv` preserves the learning rate and all losses at every step without rounding or smoothing.

The baseline and MCFA-only configurations use 24 main pairs per update and no auxiliary ranking samples. CLM/full configurations additionally use 24 same-location drone images. Their differences therefore include auxiliary sampling as well as ranking, and should not be attributed solely to one loss term.

`main_loss` combines InfoNCE with MCFA alignment when enabled. `rank_loss` is the bidirectional auxiliary ranking loss, `beta` its coefficient, and `total_loss` the recorded combined loss. Ranking-disabled runs have zero `rank_loss` and `beta`. When enabled, beta warms up over 10 updates to 0.1. Each configuration retains its actual objective weights, random seed, augmentation RNG, initialization hashes and final checkpoint hash.

## University ablation and scorer mapping

| Configuration | Training checkpoint | Archived scorer |
|---|---|---|
| Baseline | Baseline seed 4 | `global` |
| MCFA / A | MCFA-only seed 4 | `global` |
| CLM | CLM seed 4 | `relation` |
| Full CMMA / D | Full seed 4 | `relation` |
| B: scoring-only local matching | Same MCFA-only checkpoint as A | `global_orthogonal` |
| C: ranking-trained model with global scoring | Same full checkpoint as D | `global` |

`global` is the normalized global-descriptor dot product. The local/global scorers combine it with directed orthogonal local matching. B and C reuse existing checkpoints and are not additional training runs. Shared historical scorer descriptions and timings may cover more than one scoring method; the explicit scorer field identifies the exported result.

## Selected SUES within-dataset results

These are the complete seed-4 four-height records. The table displays two decimals; JSON and CSV retain the archived precision.

| Height | D2S R@1 | D2S AP | S2D R@1 | S2D AP |
|---|---:|---:|---:|---:|
| 150 m | 98.12 | 98.53 | 100.00 | 97.32 |
| 200 m | 99.48 | 99.59 | 100.00 | 98.38 |
| 250 m | 99.35 | 99.50 | 100.00 | 99.54 |
| 300 m | 99.95 | 99.96 | 100.00 | 99.67 |

## Metrics and transfer average

Primary AP is the **original trapezoidal AP**; standard AP is separately labeled. Summary metrics are percentages. Per-query AP fields are fractions nominally in [0, 1], allowing floating-point roundoff. Positive ranks are one-based and computed after junk filtering.

| Target dataset | Direction | Queries | Physical gallery | Effective gallery |
|---|---|---:|---:|---:|
| University-1652 | D2S | 37,855 | 951 | 701 |
| University-1652 | S2D | 701 | 51,355 | 37,855 |
| SUES-200 | D2S | 4,000 | 200 | 80 |
| SUES-200 | S2D | 80 | 10,000 | 4,000 |

D2S means drone to satellite and S2D satellite to drone. Gallery locations absent from the query-location set are treated as junk. Directed local scores are independently computed in the two retrieval directions.

SUES-to-University uses four separate seed-1 source-height models. Its aggregate is the equal arithmetic average of their unrounded metrics, not an ensemble of query scores. No target-dataset training or tuning is recorded for these evaluations.

| Source height | D2S R@1 | D2S AP | S2D R@1 | S2D AP |
|---|---:|---:|---:|---:|
| 150 m | 67.03 | 70.66 | 91.58 | 68.69 |
| 200 m | 74.61 | 77.75 | 93.58 | 74.53 |
| 250 m | 76.58 | 79.51 | 94.44 | 77.03 |
| 300 m | 81.21 | 83.78 | 93.58 | 78.88 |
| Mean | 74.86 | 77.92 | 93.30 | 74.78 |

## Files and environment

- `index.json`, `coverage.json`: included experiment categories, table references and file paths.
- `selection.json`: run-selection rule, candidate scores and evidence hashes.
- `results_index.csv`: every included evaluation metric at recorded precision.
- `training/<run_id>/`: selected effective configurations and complete training CSVs.
- `evaluations/<evaluation_id>/`: summary, exact checkpoint identity, protocol and all per-query records.
- `aggregates/`: the four-model transfer mean and its source evaluation IDs.
- `environments/`: recorded versions, hardware and runtime settings.
- `provenance.json`: source archive/member hashes and export transformations.
- `SHA256SUMS.txt`, `verify_records.py`: integrity and numerical-consistency checks.

Source seed-1 runs used an RTX 5090 and seed-4 runs an RTX 4090, with Python 3.10.12, PyTorch 2.7.1+cu128 and torchvision 0.22.1+cu128. Their recorded package-version lists are included. Later SUES-to-University evaluation used an RTX 4060 Laptop GPU with PyTorch 2.7.1+cu128; its recorded runtime is separate because a full local dependency snapshot was not recorded. The training environment must not be mistaken for the later evaluation environment.

Feature extraction used the archived AMP path; scoring used FP32. Effective activation checkpointing, extraction batches and scoring chunks are recorded explicitly. Cross-device bitwise-identical reproduction is not claimed.

Query paths are relative to the data root with a dataset-name prefix. All positive ranks, first-positive ranks, top-1 indices/labels and both AP definitions are retained. Absolute machine paths and top-five image paths/scores are omitted. Unused inherited configuration options are removed rather than presented as effective settings.

## Verification

From this folder, run:

```bash
python verify_records.py
```

The standard-library script checks file hashes, complete training steps and loss consistency, checkpoint links, all positive ranks, independently recomputed R@1/R@5/R@10 and both AP definitions, and the four-model mean. It checks exported-record consistency; it does not rerun inference or training. Hashes identify archived inputs and checkpoints but do not replace independent reproduction.

The public standalone implementation is at https://github.com/aBiliBill/CMMA . These records originate from the historical experimental runner and do not assert direct checkpoint compatibility with the standalone implementation.

No model weights, optimizer states, parameter tensors, feature caches, dataset images or model download links are included. Original experiment archives remain unchanged.
