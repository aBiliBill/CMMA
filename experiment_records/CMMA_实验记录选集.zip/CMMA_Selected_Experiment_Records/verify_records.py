"""Verify public experiment records using only Python's standard library.

Run from any directory: python verify_records.py [package_directory]
This checks exported records; it does not run training or load model weights.
"""

from pathlib import Path, PurePosixPath
import csv
import hashlib
import json
import math
import re
import sys


METRICS = (
    "R1_percent", "R5_percent", "R10_percent",
    "AP_trapezoid_percent", "AP_standard_percent",
)
TRAIN_FIELDS = ("step", "lr", "main_loss", "rank_loss", "beta", "total_loss")
QUERY_FIELDS = (
    "query_index", "query_label", "query_path", "positive_count",
    "positive_ranks", "first_positive_rank", "top1_gallery_index",
    "top1_gallery_label", "AP_trapezoid", "AP_standard",
    "effective_gallery_count",
)
TOLERANCE = 1e-9
SHA256 = re.compile(r"[0-9a-f]{64}")


class VerificationError(Exception):
    pass


def require(condition, message):
    if not condition:
        raise VerificationError(message)


def integer(value, where, minimum=None):
    if isinstance(value, str):
        require(bool(re.fullmatch(r"-?\d+", value)), f"{where}: expected integer")
        value = int(value)
    require(type(value) is int, f"{where}: expected integer")
    if minimum is not None:
        require(value >= minimum, f"{where}: below {minimum}")
    return value


def number(value, where):
    require(not isinstance(value, bool), f"{where}: boolean is not a number")
    try:
        result = float(value)
    except (ValueError, TypeError, OverflowError) as exc:
        raise VerificationError(f"{where}: expected finite number") from exc
    require(math.isfinite(result), f"{where}: nonfinite number")
    return result


def identifier(value, where):
    require(isinstance(value, str) and bool(value.strip()), f"{where}: empty identifier")
    return value


def digest(value, where):
    require(isinstance(value, str) and SHA256.fullmatch(value) is not None,
            f"{where}: expected lowercase SHA256")
    return value


def relative_name(value, where):
    require(isinstance(value, str) and bool(value), f"{where}: empty path")
    require("\\" not in value and ":" not in value and "\x00" not in value,
            f"{where}: path must use relative POSIX notation")
    parts = value.split("/")
    require(all(part not in ("", ".", "..") for part in parts),
            f"{where}: unsafe or noncanonical path")
    require(not PurePosixPath(value).is_absolute(), f"{where}: absolute path")
    return value


def close(actual, expected, where):
    expected = number(expected, where)
    require(abs(actual - expected) <= TOLERANCE,
            f"{where}: recomputed {actual!r}, recorded {expected!r}")


def no_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        require(key not in result, f"JSON: duplicate key {key!r}")
        result[key] = value
    return result


def read_json(path):
    with path.open(encoding="utf-8-sig") as handle:
        return json.load(handle, object_pairs_hook=no_duplicate_keys)


def read_csv(path, required):
    with path.open(encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        fields = reader.fieldnames
        require(fields is not None and len(fields) == len(set(fields)),
                f"{path.name}: missing or duplicate CSV columns")
        require(set(required).issubset(fields), f"{path.name}: missing required columns")
        records = list(reader)
    for line, row in enumerate(records, 2):
        require(None not in row and all(row[k] is not None for k in fields),
                f"{path.name}:{line}: malformed CSV row")
    return records


def verify_manifest(base):
    manifests = [name for name in ("SHA256SUMS", "SHA256SUMS.txt")
                 if (base / name).is_file()]
    require(len(manifests) == 1, "Expected exactly one SHA256SUMS or SHA256SUMS.txt")
    manifest = manifests[0]
    expected = {}
    for line_number, line in enumerate((base / manifest).read_text(encoding="utf-8-sig").splitlines(), 1):
        require(len(line) >= 67 and line[64:66] in ("  ", " *"),
                f"{manifest}:{line_number}: malformed checksum line")
        sha = digest(line[:64], f"{manifest}:{line_number}")
        name = relative_name(line[66:], f"{manifest}:{line_number}")
        require(name != manifest and name not in expected,
                f"{manifest}:{line_number}: self-reference or duplicate file")
        expected[name] = sha
    require(bool(expected), "Checksum manifest is empty")
    actual = set()
    for path in base.rglob("*"):
        require(not path.is_symlink(), f"Symbolic links are not allowed: {path.name}")
        if path.is_file():
            actual.add(path.relative_to(base).as_posix())
    missing = sorted(set(expected) - actual)
    extra = sorted(actual - set(expected) - {manifest})
    require(not missing and not extra,
            f"Checksum file coverage mismatch: missing={missing}, extra={extra}")
    for name, expected_digest in expected.items():
        checksum = hashlib.sha256()
        with (base / name).open("rb") as handle:
            for block in iter(lambda: handle.read(1024 * 1024), b""):
                checksum.update(block)
        require(checksum.hexdigest() == expected_digest, f"SHA256 mismatch: {name}")
    return expected


def ap_from_ranks(ranks):
    count = len(ranks)
    trap = []
    standard = []
    for index, rank in enumerate(ranks):
        old_precision = 1.0 if rank == 1 else index / (rank - 1)
        precision = (index + 1) / rank
        trap.append((old_precision + precision) * 0.5 / count)
        standard.append(precision / count)
    return math.fsum(trap), math.fsum(standard)


def verify_package(base):
    require(base.is_dir(), f"Package directory does not exist: {base}")
    expected = verify_manifest(base)

    def referenced(name):
        name = relative_name(name, "index reference")
        require(name in expected, f"Referenced file absent from checksum manifest: {name}")
        return base / name

    index = read_json(referenced("index.json"))
    require(isinstance(index, dict), "index.json must be an object")
    for key in ("training_runs", "evaluations", "aggregates"):
        require(isinstance(index[key], list), f"index.{key}: expected list")
    runs = {}
    training_rows = 0
    for entry in index["training_runs"]:
        run_id = identifier(entry["run_id"], "training run_id")
        require(run_id not in runs, f"Duplicate training run_id: {run_id}")
        identifier(entry["environment_id"], f"{run_id}.environment_id")
        config = read_json(referenced(entry["config_file"]))
        require(config["run_id"] == run_id, f"{run_id}: config run_id mismatch")
        checkpoint = digest(config["checkpoint_sha256"], f"{run_id}.checkpoint_sha256")
        records = read_csv(referenced(entry["training_file"]), TRAIN_FIELDS)
        updates = integer(config["training"]["optimizer_updates"], f"{run_id}.optimizer_updates", 1)
        require(len(records) == updates, f"{run_id}: missing or extra training steps")
        for step, row in enumerate(records, 1):
            where = f"{run_id}.step[{step}]"
            require(integer(row["step"], where, 1) == step, f"{where}: nonconsecutive step")
            values = {key: number(row[key], f"{where}.{key}") for key in TRAIN_FIELDS[1:]}
            require(values["lr"] >= 0 and values["beta"] >= 0,
                    f"{where}: negative learning rate or rank-loss coefficient")
            calculated = values["main_loss"] + values["beta"] * values["rank_loss"]
            require(math.isclose(calculated, values["total_loss"], rel_tol=1e-5, abs_tol=1e-6),
                    f"{where}: total_loss does not match main_loss + beta * rank_loss")
        training_rows += len(records)
        runs[run_id] = {"checkpoint_sha256": checkpoint}

    evaluations = {}
    query_rows = 0
    for entry in index["evaluations"]:
        evaluation_id = identifier(entry["evaluation_id"], "evaluation_id")
        require(evaluation_id not in evaluations, f"Duplicate evaluation_id: {evaluation_id}")
        summary = read_json(referenced(entry["summary_file"]))
        require(summary["evaluation_id"] == evaluation_id, f"{evaluation_id}: summary ID mismatch")
        run_id = identifier(summary["run_id"], f"{evaluation_id}.run_id")
        require(run_id in runs, f"{evaluation_id}: unknown training run {run_id}")
        require(summary["checkpoint_sha256"] == runs[run_id]["checkpoint_sha256"],
                f"{evaluation_id}: checkpoint does not match training run")
        direction = summary["direction"]
        require(direction in ("D2S", "S2D"), f"{evaluation_id}: invalid direction")
        require(bool(summary["scorer"]), f"{evaluation_id}: missing scorer")
        counts = summary["counts"]
        count = integer(counts["query_count"], f"{evaluation_id}.query_count", 1)
        gallery_count = integer(counts["effective_gallery_count"], f"{evaluation_id}.gallery_count", 1)
        records = read_csv(referenced(entry["queries_file"]), QUERY_FIELDS)
        require(len(records) == count, f"{evaluation_id}: query row count mismatch")
        first_ranks, traps, standards, positives = [], [], [], []
        for query_index, row in enumerate(records):
            where = f"{evaluation_id}.query[{query_index}]"
            require(integer(row["query_index"], where, 0) == query_index,
                    f"{where}: query indices must be complete and consecutive")
            label = integer(row["query_label"], f"{where}.query_label")
            top_label = integer(row["top1_gallery_label"], f"{where}.top1_gallery_label")
            top_index = integer(row["top1_gallery_index"], f"{where}.top1_gallery_index", 0)
            if "physical_gallery_count" in counts:
                physical_count = integer(counts["physical_gallery_count"], f"{evaluation_id}.physical_gallery_count", 1)
                require(top_index < physical_count, f"{where}: top1 index outside physical gallery")
            relative_name(row["query_path"], f"{where}.query_path")
            ranks = json.loads(row["positive_ranks"])
            require(isinstance(ranks, list) and bool(ranks), f"{where}: no positive ranks")
            require(all(type(rank) is int and 1 <= rank <= gallery_count for rank in ranks),
                    f"{where}: positive rank outside effective gallery")
            require(all(a < b for a, b in zip(ranks, ranks[1:])),
                    f"{where}: positive ranks must be strictly increasing")
            positive_count = integer(row["positive_count"], f"{where}.positive_count", 1)
            require(positive_count == len(ranks), f"{where}: positive count mismatch")
            require(integer(row["effective_gallery_count"], f"{where}.gallery_count", 1) == gallery_count,
                    f"{where}: effective gallery size mismatch")
            require(integer(row["first_positive_rank"], f"{where}.first_positive_rank", 1) == ranks[0],
                    f"{where}: first positive rank mismatch")
            require((top_label == label) == (ranks[0] == 1),
                    f"{where}: top1 label disagrees with first positive rank")
            trap, standard = ap_from_ranks(ranks)
            close(trap, row["AP_trapezoid"], f"{where}.AP_trapezoid")
            close(standard, row["AP_standard"], f"{where}.AP_standard")
            first_ranks.append(ranks[0])
            traps.append(trap)
            standards.append(standard)
            positives.append(positive_count)
        require(integer(counts["positive_count_min"], f"{evaluation_id}.positive_count_min", 1) == min(positives),
                f"{evaluation_id}: positive_count_min mismatch")
        require(integer(counts["positive_count_max"], f"{evaluation_id}.positive_count_max", 1) == max(positives),
                f"{evaluation_id}: positive_count_max mismatch")
        metrics = {f"R{k}_percent": sum(rank <= k for rank in first_ranks) / count * 100
                   for k in (1, 5, 10)}
        metrics["AP_trapezoid_percent"] = math.fsum(traps) / count * 100
        metrics["AP_standard_percent"] = math.fsum(standards) / count * 100
        for key in METRICS:
            close(metrics[key], summary["metrics"][key], f"{evaluation_id}.{key}")
        query_rows += count
        evaluations[evaluation_id] = {
            "run_id": run_id, "direction": direction, "metrics": metrics,
            "checkpoint_sha256": summary["checkpoint_sha256"],
        }

    aggregate_results = []
    aggregate_ids = set()
    for entry in index["aggregates"]:
        aggregate = read_json(referenced(entry["aggregate_file"]))
        aggregate_id = identifier(aggregate["aggregate_id"], "aggregate_id")
        require(aggregate_id not in aggregate_ids, f"Duplicate aggregate_id: {aggregate_id}")
        aggregate_ids.add(aggregate_id)
        require(aggregate["method"] == "equal_arithmetic_mean_of_four_source_models",
                f"{aggregate_id}: unsupported aggregation method")
        source_runs = {}
        for direction in ("D2S", "S2D"):
            ids = aggregate["source_evaluation_ids"][direction]
            require(isinstance(ids, list) and len(ids) == 4 and len(set(ids)) == 4,
                    f"{aggregate_id}.{direction}: expected four distinct evaluation IDs")
            require(all(item in evaluations for item in ids), f"{aggregate_id}: unknown source evaluation")
            sources = [evaluations[item] for item in ids]
            require(all(item["direction"] == direction for item in sources),
                    f"{aggregate_id}.{direction}: wrong source direction")
            source_runs[direction] = {item["run_id"] for item in sources}
            require(len(source_runs[direction]) == 4 and len({item["checkpoint_sha256"] for item in sources}) == 4,
                    f"{aggregate_id}.{direction}: expected four distinct source models")
            for key in METRICS:
                mean = math.fsum(item["metrics"][key] for item in sources) / 4
                close(mean, aggregate["metrics"][direction][key], f"{aggregate_id}.{direction}.{key}")
        require(source_runs["D2S"] == source_runs["S2D"], f"{aggregate_id}: directions use different source models")
        aggregate_results.append(aggregate_id)

    actual_counts = {
        "training_runs": len(runs), "training_rows": training_rows,
        "evaluations": len(evaluations), "query_rows": query_rows,
    }
    for key, value in actual_counts.items():
        require(integer(index["counts"][key], f"index.counts.{key}", 0) == value,
                f"index.counts.{key}: expected {value}, found {index['counts'][key]!r}")
    return {
        "status": "PASS", "files_verified": len(expected), **actual_counts,
        "aggregates_verified": aggregate_results,
        "checks": {
            "sha256_and_complete_file_coverage": True,
            "complete_training_steps_and_finite_values": True,
            "training_loss_identity": True,
            "evaluation_checkpoint_identity": True,
            "complete_query_indices_and_positive_ranks": True,
            "ap_and_recall_recomputed_from_ranks": True,
            "four_model_means_recomputed": True,
        },
        "metric_absolute_tolerance": TOLERANCE,
        "scope": "Checks exported record integrity and internal consistency; does not rerun the experiments.",
    }


def main():
    try:
        require(len(sys.argv) <= 2, "Usage: python verify_records.py [package_directory]")
        base = Path(sys.argv[1]).resolve() if len(sys.argv) == 2 else Path(__file__).resolve().parent
        result = verify_package(base)
    except (VerificationError, OSError, ValueError, KeyError, TypeError, csv.Error) as exc:
        print(json.dumps({"status": "FAIL", "error": str(exc)}, ensure_ascii=False, indent=2))
        return 1
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
